-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 23 Sep 2016 pada 05.13
-- Versi Server: 5.7.11
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wordscramble`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'handi', 'tugasbiznet23');

-- --------------------------------------------------------

--
-- Struktur dari tabel `point`
--

CREATE TABLE `point` (
  `id` int(11) NOT NULL,
  `pointgame` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `point`
--

INSERT INTO `point` (`id`, `pointgame`) VALUES
(1, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `word`
--

CREATE TABLE `word` (
  `no` int(3) NOT NULL,
  `word` text NOT NULL,
  `scramble` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `word`
--

INSERT INTO `word` (`no`, `word`, `scramble`) VALUES
(1, 'BOOK', 'OKBO'),
(2, 'PAPER', 'RAPER'),
(3, 'MICROSCOPE', 'PERCSOICMO'),
(4, 'TEMPERATURE', 'EMEERTRUAPT'),
(5, 'ELEPHANT', 'ATEPLHEN'),
(6, 'CONTINENT', 'NICNTETON'),
(7, 'EXPERIMENT', 'EREMIENXTP'),
(8, 'NUCLEUS', 'UCSLEUN'),
(9, 'MOLECULE', 'CELEOLMU'),
(10, 'PLATINUM', 'NPALMTIU'),
(11, 'SKELETON', 'EOKSLENT'),
(12, 'METAMORPHOSIS', 'MRTISAPSMOOEH'),
(13, 'THREE', 'HEETR'),
(14, 'THREE', 'HEETR'),
(15, '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `point`
--
ALTER TABLE `point`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `word`
--
ALTER TABLE `word`
  ADD PRIMARY KEY (`no`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
