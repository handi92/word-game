<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>

	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	#body {
		margin: 0 25px 25px 25px;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	#cssformadmin{
		border: 1px solid #D0D0D0;
		width: 250px;
		height: 250px;
		font-family:Georgia, "Times New Roman", Times, serif;
		margin: 10px 0 0 0;
		padding: 25px 50px;
	}
	input[type=text],input[type=password] {
    	width: 100%;
    	padding: 12px 20px;
    	margin: 8px 0;
    	box-sizing: border-box;
	}
	input[type=button], input[type=submit], input[type=reset] {
    	background-color: #4CAF50;
    	border: none;
    	color: white;
    	padding: 16px 32px;
    	text-decoration: none;
    	margin: 4px 2px;
    	cursor: pointer;
	}
	</style>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
</head>
<body>

<div id="container">
	<h1>Admin Scramble Game!</h1>

	<div id="body">
		<div id="cssformadmin">
		<form action="<?php echo base_url('admin/admin'); ?>" method="post">
			Username : <input type="text" name="username" id="username"/>
			Password : <input type="password" name="password" id="password"/>
			<input type="submit" value="ADMIN"/>
		</form>
		<form action="<?php echo base_url('form/selesai_game'); ?>" method="post">
			<input type="submit" value="Back To Game"/>
		</form>
		</div>
	</div>
</div>

</body>
</html>