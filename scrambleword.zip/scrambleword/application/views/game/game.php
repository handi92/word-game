<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>

	<style type="text/css">
		::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	#body {
		margin: 0 15px 450px 15px;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	input[type=text] {
    	width: 100%;
    	padding: 12px 20px;
    	margin: 8px 0;
    	box-sizing: border-box;
	}
	input[type=button], input[type=submit], input[type=reset] {
    	background-color: #4CAF50;
    	border: none;
    	color: white;
    	padding: 16px 32px;
    	text-decoration: none;
    	margin: 4px 2px;
    	cursor: pointer;
	}
	#gameform {
		border: 1px solid #D0D0D0;
		width: 250px;
		height: 250px;
		padding: 25px 100px;
		float: right;
	}
	#question {
		font-size: 36px;
		font-family:Georgia, "Times New Roman", Times, serif;
		color: #000099;
	}
	#point {
		font-size: 36px;
		font-family:Georgia, "Times New Roman", Times, serif;
		color: #000099;
	}
	#show {
		font-size: 18px;
		font-family:Georgia, "Times New Roman", Times, serif;
		color: #000099;
	}
	#feedback {
		font-size: 12px;
		font-family:Georgia, "Times New Roman", Times, serif;
		color: #000099;
	}
	#result {
		border: 1px solid #D0D0D0;
		width: 250px;
		height: 250px;
		padding: 25px 100px;
		float: left;
	}
	p {
		font-size: 12px;
		font-family:Georgia, "Times New Roman", Times, serif;
		color: #000099;
	}
	#btnendcss {
		margin: 150px 0 50px 550px;
	}
	</style>
	

	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
	<script type="text/javascript" >
		$(document).ready(function()
		{		
				var url = "<?php echo base_url('game/pertanyaan'); ?>";
				$.ajax({
					url: url,
					dataType: 'json',
					type: 'GET',
					success: function(data, textStatus, XMLHttpRequest)
					{
						$("#question").html(data.scramble);
						$("#questval").val(data.scramble);
						$("#point").html(data.point);
						$("#feedback").html(data.feddback);
					},
					error: function(XMLHttpRequest, textStatus, errorThrown)
					{
						$("#question").html('Error connecting to:' + url);
					}
					});
		
		});
		
		$(document).ready(function()
		{
			$("#btn").click(function(){
			
					var answer = $('#answer').val();
					var scram = $('#questval').val();
					var json = {answer,scram};
					var url = "<?php echo base_url('game/cek_jawaban'); ?>";
			if(answer == null || answer == '')
			{
				$("#cekanswer").html('You Must Answer');
				
			}
			else
			{
				$.ajax({
					url: url,
					dataType: 'json',
					type: 'POST',
					data: json,
					success: function(data, textStatus, XMLHttpRequest)
					{
						$("#show").html(data.answer);
						setTimeout(function () { location.reload(1); }, 700);
					},
					error: function(XMLHttpRequest, textStatus, errorThrown)
					{
						$("#show").html('Error connecting to:' + url);
					}
					});
			
				
			}	
					//$("#show").html('loading...');
				});
				
				$( "#answer" ).keyup(function( event ) {
  				if ( event.which == 13 ) {
   				 event.preventDefault();
				 $("#btn").click();
  				}
				});
				
			});
				
	</script>
</head>
<body background="../../../picture/bacground.jpg">

<div id="container">
	<h1>Scramble Game!</h1>

	<div id="body">
		<div id="gameform">
		<p>Scramble Game.</p>
		<p id="question"></p>
		<input type="hidden" id="questval"></input>
		
		<input type="text" name="answer" id="answer"/><p id="cekanswer"></p>
			
		<input type="button" id="btn" value="ANSWER" /><?php echo validation_errors(); ?>  
		
		</div>
		
		<div id="result">
			<p id="show"></p>
		
			<h1>POINT</h1>
			<h2 id="point">0</h2>
			<h2 id="feedback"></h2>
		</div>
		
	</div>
	
		<div id="btnendcss">
			<?php echo form_open(base_url().'form/selesai_game'); ?>
			<?php echo form_submit('submit','END GAME'); ?>
			<?php echo form_close(); ?>
		</div>
</div>

</body>
</html>