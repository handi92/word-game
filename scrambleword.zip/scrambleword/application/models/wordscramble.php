<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	class WordScramble extends CI_Model{
		
		
		public function _construct()
		{
			parent::_construct();
		}
		
		public function cek_scramble($cek)
		{
			$query = $this->db->query("select * from word where scramble='".$cek."'");
			return $query->row_array();
		}
		
		public function get_scramble()
		{
			$query = $this->db->query("select scramble from word order by RAND() LIMIT 1");
			return $query->row_array();
		}
		
		public function get_point()
		{
			$query = $this->db->query("select pointgame from point");
			return $query->row_array();
		}
		public function point_accumulation($point)
		{
			$this->db->set('pointgame', $point);
			$this->db->where('id', 1);
			$this->db->update('point');
		}
		public function get_admin()
		{
			$query = $this->db->query("select * from admin");
			return $query->row_array();
		}
		public function get_id()
		{
			$query = $this->db->query("select MAX(no) as nomax from word");
			return $query->row_array();
		}
		public function insertword($no,$word,$scramble)
		{
			$this->db->query("insert into word (no,word,scramble) values (".$no.",'".$word."','".$scramble."')");
		}
	}
?>