<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function __construct()
	{
		parent::__construct();
		$this->load->library('session');
		$this->load->model('wordscramble');
		$this->load->library('ajax');
		$this->load->helper('security');
	}
	
	public function mulai_admin()
	{
		$this->load->view('admin/login');
	}
	
	public function admin()
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		
		$admin = $this->wordscramble->get_admin();
		$useradmin = $admin['username'];
		$passadmin = $admin['password'];  
		$passadminw = do_hash($passadmin,'md5');
		
		if($username == $useradmin && $password == $passadmin)
		{
			$this->session->set_userdata($useradmin,$passadminw);
			$data['useradmin'] = $useradmin;
			$data['userpass'] = $passadminw;
			$this->load->view('admin/admin',$data);
		}
		else
		{
			$failed['failed'] = "Failed to Login, enter correct username and password";
			$this->load->view('admin/login',$failed);
		}
		
		
	}
	public function selesai_admin()
	{
		$username = $this->input->post('useradmin');
		$password = $this->input->post('userpass');
		$arr = array($username,$password);
		$this->session->unset_userdata($arr);
		$this->load->view('admin/login');
	}
	
	public function insert()
	{
		$word = strtoupper($this->input->post('word'));
		$scramble = strtoupper($this->input->post('scramble'));
		
		$no = $this->wordscramble->get_id();
		$nomax = $no['nomax'] +1 ;
		//$newid = $idmax + 1;
		$this->wordscramble->insertword($nomax,$word,$scramble);
	}
}
