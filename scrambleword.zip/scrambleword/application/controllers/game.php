<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Game extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->library('ajax');
		$this->load->library('form_validation');
		$this->load->model('wordscramble');
	}
	public function index(){
		$this->load->view('game/game');
	}
	public function pertanyaan()
	{
		
		$tab = $this->wordscramble->get_scramble();
		$pnt = $this->wordscramble->get_point();
		$scramble = $tab['scramble'];
		$point = $pnt['pointgame'];
		$arr['scramble'] = $scramble;
		$arr['point'] = $point;
		
		if($point > 1){
			$arr['feddback'] = 'your performance was good, keep it up';
		}
		else if($point == 0)
		{
			$arr['feddback'] = '';
		}
		else 
		{
			$arr['feddback'] = 'your performance was bad';
		}
		
		$this->ajax->output_ajax($arr);
	}
	public function cek_jawaban()
	{
		$sr = $this->input->post('scram');	
		$pnt = $this->wordscramble->get_point();
		$tab = $this->wordscramble->cek_scramble($sr);	

		$scramble = $tab['scramble'];
		$word = $tab['word'];
		$point = $pnt['pointgame'];
		
					if (strtoupper($this->input->post('answer')) == '')
					{
						$arr['answer'] = 'You Not Answer';
					}
					else
					{
						if(strtoupper($this->input->post('answer')) == $word)
						{
							$accumulation = $point + 1;
							$arr['answer'] = 'Correct Get 1 Point'.' ';
							$this->wordscramble->point_accumulation($accumulation);
							$arr['showpoint'] = $accumulation;
						}
						else
						{
							$accumulation = $point - 1;
							$arr['answer'] = 'Wrong Loss 1 Point'.' '; 
							$this->wordscramble->point_accumulation($accumulation);
						}
					}
		$this->ajax->output_ajax($arr);
	}
}
