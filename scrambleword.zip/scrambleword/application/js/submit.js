$(document).ready(function(){
  $("#submit").click(function(){
    $("#form").submit();
  });
});

